#include <stdio.h>
int main(){
    int number1=2;
    int number2=0;
    int result=number1/number2;
    printf("Result: %d\n",result);
    return 0;
}