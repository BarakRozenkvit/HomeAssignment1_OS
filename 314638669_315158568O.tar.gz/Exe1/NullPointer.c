#include <stdio.h>
int main(){
    int *ptr=NULL;
    *ptr=10;
    return 0;
}