#include <math.h>
#include <stdio.h>
float factorial(int k);
long double poisson(int k,double lambda);
