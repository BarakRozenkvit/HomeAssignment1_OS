
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
//#include <cstdio>
int minDistance(int dist[], bool sptSet[],int size);
void dijkstra(int ** graph,int size, int src);
