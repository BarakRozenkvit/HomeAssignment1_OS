#include <stdlib.h>
#include <stdio.h>

int* createArray(int randomSeed,int size);